
public interface view {
	public void start();
}
