/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */

package pdgame;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.List;
import javax.swing.filechooser.FileFilter;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Brian
 */
public class TestLoader extends JFileChooser
{

    private AppFrame parent;
    private Lattice l;
    private FileFilter fs = new FileFilter()
    {

        @Override
        public boolean accept(File f)
        {
            if (f.isDirectory()) {
                return true;
            }

            if (f.getAbsolutePath().endsWith(".txt")) {
                return true;
            }
            return false;
        }

        @Override
        public String getDescription()
        {
            return ("*.txt Text File");
        }
    };

    public TestLoader(AppFrame parent, Lattice l)
    {
        this.parent = parent;
        this.l = l;
        this.setFileFilter(fs);
    }

    @Override
    public int showOpenDialog(Component parent)
    {
        int i;
        while ((i = super.showOpenDialog(parent))
                == PdgameFileChooser.APPROVE_OPTION && !this.getSelectedFile().
                exists());
        return i;
    }

    public void test()
    {
        List<String[]> sTests = new LinkedList<String[]>();
        List<Test> tests = new LinkedList<Test>();

        if (this.showOpenDialog(parent) == this.APPROVE_OPTION) {
            try {

                BufferedReader br =
                        new BufferedReader(
                        new FileReader(this.getSelectedFile()));

                String s = br.readLine();
                while (s != null) {
                    sTests.add(s.split(" "));
                    s = br.readLine();
                }


                String sFile;

                for (String[] S : sTests) {
                    Test t = new Test();
                    t.sFileName = S[0];
                    t.iNumber = Integer.parseInt(S[1]);
                    t.iWidth = Integer.parseInt(S[2]);
                    t.iHeight = Integer.parseInt(S[3]);
                    t.iRounds = Integer.parseInt(S[4]);

                    String[] subS = S[5].split(",");
                    int[][] iS = {{Integer.parseInt(subS[0]), Integer.parseInt(
                            subS[1])}, {Integer.parseInt(subS[2]), Integer.
                            parseInt(subS[3])}};
                    t.iScheme = iS;
                    t.sInitial = S[6];
                    t.sStat = S[7];

                    t.iLength = Integer.parseInt(S[8]);
                    int[] iFreeze = null;
                    if (S.length == 10) {
                        subS = S[9].split(",");
                        iFreeze = new int[subS.length];
                        for (int j = 0; j < subS.length; j++) {
                            iFreeze[j] = Integer.parseInt(subS[j]);
                        }
                    }

                    t.iFreeze = iFreeze;
                    tests.add(t);
                }


                l.testMode(tests);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(parent,
                        "Error in reading the test file.");
                ex.printStackTrace();
            }

        }
    }
}
