/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */
package pdgame;

import java.awt.Dimension;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import stats.*;

/**
 *
 * @author Brian
 * @version 2.0 Stats saved as csv files, screen shows upon starting a new simulation.
 * No known bugs and/or errors. Complete as can be for now.
 * @since 1.8 Stats added, and functionality made for all buttons. Additional
 * load options added, and comments put in necessary classes.
 * 1.5 Bugs involving threading issues resolved. Comments added.
 */
public class AppFrame extends javax.swing.JFrame
{

    private PdgameFileChooser Pdg = new PdgameFileChooser();
    private int[] iPalette = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    private Lattice l = new Lattice(iPalette, this);

    /** Creates new form AppFrame */
    public AppFrame()
    {
        try {
            // Set System L&F
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }
        initComponents();
    }

    public Lattice getLattice()
    {
        return l;
    }

    public void writeRuleText(int[] iRule)
    {
        String s = "Inst #" + iRule[0];
        s += "\nA/T =(" + ((iRule[0] & 0xFF00) >> 8) + ", " + ((iRule[0] & 0xFF)
                >> 1) + ")";
        s += "\nPoints: " + iRule[1];
        s += "\nNext Inst #" + iRule[2] + "\n";
        s += "\n0 = Defect, \n1 = Cooperate";
        for (int i = 1; i < 16; i++) //Skip the first line, since it is the throw away line anyway.
        {
            s += "\n";
            boolean M = false;
            for (int j = 3; j >= 0; j--) {
                if (!M) {
                    if (((i >> j) & 1) == 0) {
                        s += "X";
                    }
                    else {
                        M = true;
                        s += "X";
                    }
                }
                else {
                    if (((i >> j) & 1) == 0) {
                        s += "0";
                    }
                    else {
                        s += "1";
                    }
                }
            }

            if (((iRule[0] >> i) & 1) == 0) {
                s += ":  Defect";
            }
            else {
                s += ":  Cooperate";
            }
        }
        RuleText.setText(s);
        RuleText.setCaretPosition(0);
    }

    public void setPanel(JPanel jp)
    {
        AppScreen = new JScrollPane(jp);
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
    }

    public void writeStats(String s)
    {
        StatsText.setText(s);
    }

    public void updateRuleGUI()
    {
        Rule0.setText(iPalette[0] + "");
        Rule1.setText(iPalette[1] + "");
        Rule2.setText(iPalette[2] + "");
        Rule3.setText(iPalette[3] + "");
        Rule4.setText(iPalette[4] + "");
        Rule5.setText(iPalette[5] + "");
        Rule6.setText(iPalette[6] + "");
        Rule7.setText(iPalette[7] + "");
        Rule8.setText(iPalette[8] + "");
        Rule9.setText(iPalette[9] + "");
    }

    public void newSim(String s)
    {
        if(s.equals("random"))
        {
            dRandom.doClick();
        }
        else if(s.equals("onemem"))
        {
            OneMem.doClick();
        }
        else if(s.equals("twomem"))
        {
            TwoMem.doClick();
        }
        else if(s.equals("selfish"))
        {
            Selfish.doClick();
        }
        else if(s.equals("selfless"))
        {
            Selfless.doClick();
        }
        else if(s.equals("palette"))
        {
            Palette.doClick();
        }
    }

    public void newStat(String s)
    {
        if(s.equals("first"))
        {
            FirstMoves.doClick();
        }
        else if(s.equals("specific"))
        {
            SpecificPalette.doClick();
        }
        else if(s.equals("hamming"))
        {
            HammingDistance.doClick();
        }
        else if(s.equals("dna"))
        {
            DNA.doClick();
        }
        else if(s.equals("total"))
        {
            TotalPoints.doClick();
        }
        
        if(!Record.isSelected())
        {
            Record.doClick();
        }

    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        StatsButtons = new javax.swing.ButtonGroup();
        AppSplit = new javax.swing.JSplitPane();
        AppControl = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        RuleText = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Rule1 = new javax.swing.JTextField();
        Rule2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Rule4 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Rule3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Rule6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Rule5 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Rule8 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Rule7 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Rule0 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        Rule9 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        StatsText = new javax.swing.JTextArea();
        AppScreen = new javax.swing.JScrollPane();
        AppBar = new javax.swing.JMenuBar();
        File = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        dRandom = new javax.swing.JMenuItem();
        OneMem = new javax.swing.JMenuItem();
        TwoMem = new javax.swing.JMenuItem();
        Selfish = new javax.swing.JMenuItem();
        Selfless = new javax.swing.JMenuItem();
        Palette = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        Save = new javax.swing.JMenuItem();
        SaveAs = new javax.swing.JMenuItem();
        Open = new javax.swing.JMenuItem();
        Import = new javax.swing.JMenuItem();
        AutoTest = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        SaveStxt = new javax.swing.JMenuItem();
        SaveScreen = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        Exit = new javax.swing.JMenuItem();
        Options = new javax.swing.JMenu();
        WidthHeight = new javax.swing.JMenuItem();
        PointScheme = new javax.swing.JMenuItem();
        FPS = new javax.swing.JMenuItem();
        Rounds = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        Zin = new javax.swing.JMenuItem();
        Zout = new javax.swing.JMenuItem();
        PointView = new javax.swing.JCheckBoxMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        FullScreen = new javax.swing.JMenuItem();
        Statistics = new javax.swing.JMenu();
        Record = new javax.swing.JCheckBoxMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        FirstMoves = new javax.swing.JRadioButtonMenuItem();
        SpecificPalette = new javax.swing.JRadioButtonMenuItem();
        HammingDistance = new javax.swing.JRadioButtonMenuItem();
        DNA = new javax.swing.JRadioButtonMenuItem();
        TotalPoints = new javax.swing.JRadioButtonMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Prisoner's Dilemna Cellular Automata Simulator");

        AppSplit.setDividerLocation(600);

        AppControl.setMaximumSize(new java.awt.Dimension(200, 32767));
        AppControl.setPreferredSize(new java.awt.Dimension(200, 577));

        RuleText.setColumns(20);
        RuleText.setEditable(false);
        RuleText.setRows(10);
        jScrollPane1.setViewportView(RuleText);

        jLabel1.setText("Palette");

        jLabel2.setText("1:");

        Rule1.setText("-1");
        Rule1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule1FocusLost(evt);
            }
        });

        Rule2.setText("-1");
        Rule2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule2FocusLost(evt);
            }
        });

        jLabel3.setText("2:");

        Rule4.setText("-1");
        Rule4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule4FocusLost(evt);
            }
        });

        jLabel4.setText("4:");

        Rule3.setText("-1");
        Rule3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule3FocusLost(evt);
            }
        });

        jLabel5.setText("3:");

        Rule6.setText("-1");
        Rule6.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule6FocusLost(evt);
            }
        });

        jLabel6.setText("6:");

        Rule5.setText("-1");
        Rule5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule5FocusLost(evt);
            }
        });

        jLabel7.setText("5:");

        Rule8.setText("-1");
        Rule8.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule8FocusLost(evt);
            }
        });

        jLabel8.setText("8:");

        Rule7.setText("-1");
        Rule7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule7FocusLost(evt);
            }
        });

        jLabel9.setText("7:");

        Rule0.setText("-1");
        Rule0.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule0FocusLost(evt);
            }
        });

        jLabel10.setText("0:");

        Rule9.setText("-1");
        Rule9.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Rule9FocusLost(evt);
            }
        });

        jLabel11.setText("9:");

        jLabel12.setText("Statistics");

        StatsText.setColumns(20);
        StatsText.setEditable(false);
        StatsText.setRows(5);
        jScrollPane2.setViewportView(StatsText);

        javax.swing.GroupLayout AppControlLayout = new javax.swing.GroupLayout(AppControl);
        AppControl.setLayout(AppControlLayout);
        AppControlLayout.setHorizontalGroup(
            AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AppControlLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, AppControlLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                        .addGap(1, 1, 1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, AppControlLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
                        .addGap(1, 1, 1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, AppControlLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(151, 151, 151))
                    .addGroup(AppControlLayout.createSequentialGroup()
                        .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(AppControlLayout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Rule1, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addGap(5, 5, 5))
                            .addGroup(AppControlLayout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Rule3, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(AppControlLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Rule5, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(AppControlLayout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Rule7, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(AppControlLayout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Rule9, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Rule0, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                            .addComponent(Rule8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                            .addComponent(Rule6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                            .addComponent(Rule4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                            .addComponent(Rule2, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, AppControlLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(142, 142, 142)))
                .addGap(9, 9, 9))
        );
        AppControlLayout.setVerticalGroup(
            AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AppControlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 14, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Rule1, 0, 0, Short.MAX_VALUE)
                    .addComponent(Rule2, 0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Rule3, 0, 0, Short.MAX_VALUE)
                        .addComponent(Rule4, 0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4))
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Rule5, 0, 0, Short.MAX_VALUE)
                        .addComponent(Rule6, 0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel6))
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Rule8, 0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel8))
                    .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(Rule7, 0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AppControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Rule9, 0, 0, Short.MAX_VALUE)
                        .addComponent(Rule0, 0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel10))
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 14, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                .addContainerGap())
        );

        AppSplit.setRightComponent(AppControl);
        AppSplit.setLeftComponent(AppScreen);

        File.setText("File");

        jMenu1.setText("New");

        dRandom.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        dRandom.setText("Random");
        dRandom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dRandomActionPerformed(evt);
            }
        });
        jMenu1.add(dRandom);

        OneMem.setText("1 Memory");
        OneMem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OneMemActionPerformed(evt);
            }
        });
        jMenu1.add(OneMem);

        TwoMem.setText("2 Memory");
        TwoMem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TwoMemActionPerformed(evt);
            }
        });
        jMenu1.add(TwoMem);

        Selfish.setText("Selfish");
        Selfish.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelfishActionPerformed(evt);
            }
        });
        jMenu1.add(Selfish);

        Selfless.setText("Selfless");
        Selfless.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelflessActionPerformed(evt);
            }
        });
        jMenu1.add(Selfless);

        Palette.setText("Palette");
        Palette.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaletteActionPerformed(evt);
            }
        });
        jMenu1.add(Palette);

        File.add(jMenu1);
        File.add(jSeparator3);

        Save.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        Save.setText("Save");
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });
        File.add(Save);

        SaveAs.setText("Save As");
        SaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveAsActionPerformed(evt);
            }
        });
        File.add(SaveAs);

        Open.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        Open.setText("Open");
        Open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpenActionPerformed(evt);
            }
        });
        File.add(Open);

        Import.setText("Import Image(.png)");
        Import.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImportActionPerformed(evt);
            }
        });
        File.add(Import);

        AutoTest.setText("Import AutoTest(.txt)");
        AutoTest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutoTestActionPerformed(evt);
            }
        });
        File.add(AutoTest);
        File.add(jSeparator1);

        SaveStxt.setText("Save Stats (.csv)");
        SaveStxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveStxtActionPerformed(evt);
            }
        });
        File.add(SaveStxt);

        SaveScreen.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        SaveScreen.setText("Save Screen");
        SaveScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveScreenActionPerformed(evt);
            }
        });
        File.add(SaveScreen);
        File.add(jSeparator2);

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        File.add(Exit);

        AppBar.add(File);

        Options.setText("Options");

        WidthHeight.setText("Width/Height");
        WidthHeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WidthHeightActionPerformed(evt);
            }
        });
        Options.add(WidthHeight);

        PointScheme.setText("Point Scheme");
        PointScheme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PointSchemeActionPerformed(evt);
            }
        });
        Options.add(PointScheme);

        FPS.setText("FPS Rate");
        FPS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FPSActionPerformed(evt);
            }
        });
        Options.add(FPS);

        Rounds.setText("Rounds");
        Rounds.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoundsActionPerformed(evt);
            }
        });
        Options.add(Rounds);
        Options.add(jSeparator4);

        Zin.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_EQUALS, java.awt.event.InputEvent.CTRL_MASK));
        Zin.setText("Zoom In");
        Zin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZinActionPerformed(evt);
            }
        });
        Options.add(Zin);

        Zout.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_MINUS, java.awt.event.InputEvent.CTRL_MASK));
        Zout.setText("Zoom Out");
        Zout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZoutActionPerformed(evt);
            }
        });
        Options.add(Zout);

        PointView.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_G, java.awt.event.InputEvent.CTRL_MASK));
        PointView.setText("Point View");
        PointView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PointViewActionPerformed(evt);
            }
        });
        Options.add(PointView);
        Options.add(jSeparator6);

        FullScreen.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
        FullScreen.setText("Full Screen");
        FullScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FullScreenActionPerformed(evt);
            }
        });
        Options.add(FullScreen);

        AppBar.add(Options);

        Statistics.setText("Statistics");
        StatsButtons.add(Statistics);

        Record.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        Record.setText("Record");
        Record.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RecordActionPerformed(evt);
            }
        });
        Statistics.add(Record);
        Statistics.add(jSeparator5);

        StatsButtons.add(FirstMoves);
        FirstMoves.setText("First Moves");
        FirstMoves.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstMovesActionPerformed(evt);
            }
        });
        Statistics.add(FirstMoves);

        StatsButtons.add(SpecificPalette);
        SpecificPalette.setText("Palette Rules");
        SpecificPalette.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SpecificPaletteActionPerformed(evt);
            }
        });
        Statistics.add(SpecificPalette);

        StatsButtons.add(HammingDistance);
        HammingDistance.setText("Hamming Distance");
        HammingDistance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HammingDistanceActionPerformed(evt);
            }
        });
        Statistics.add(HammingDistance);

        StatsButtons.add(DNA);
        DNA.setText("Instruction Set");
        DNA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DNAActionPerformed(evt);
            }
        });
        Statistics.add(DNA);

        StatsButtons.add(TotalPoints);
        TotalPoints.setText("Total Points");
        TotalPoints.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalPointsActionPerformed(evt);
            }
        });
        Statistics.add(TotalPoints);

        AppBar.add(Statistics);

        setJMenuBar(AppBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(AppSplit, javax.swing.GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(AppSplit, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void WidthHeightActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_WidthHeightActionPerformed
    {//GEN-HEADEREND:event_WidthHeightActionPerformed
        new WidthHeight(this, true).setVisible(true);
    }//GEN-LAST:event_WidthHeightActionPerformed

    private void Rule3FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule3FocusLost
    {//GEN-HEADEREND:event_Rule3FocusLost
        try {
            iPalette[3] = Integer.parseInt(Rule3.getText());
            if (iPalette[3] > 0xFFFE) {
                iPalette[3] = 0xFFFE;
                Rule3.setText(iPalette[3] + "");
            }
        } catch (Exception e) {
            iPalette[3] = -1;
            Rule3.setText(iPalette[3] + "");
        }
    }//GEN-LAST:event_Rule3FocusLost

    private void Rule1FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule1FocusLost
    {//GEN-HEADEREND:event_Rule1FocusLost
        try {
            iPalette[1] = Integer.parseInt(Rule1.getText());
            if (iPalette[1] > 0xFFFE) {
                iPalette[1] = 0xFFFE;
                Rule1.setText(iPalette[1] + "");
            }
        } catch (Exception e) {
            iPalette[1] = -1;
            Rule1.setText(iPalette[1] + "");
        }
    }//GEN-LAST:event_Rule1FocusLost

    private void Rule2FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule2FocusLost
    {//GEN-HEADEREND:event_Rule2FocusLost
        try {
            iPalette[2] = Integer.parseInt(Rule2.getText());
            if (iPalette[2] > 0xFFFE) {
                iPalette[2] = 0xFFFE;
                Rule2.setText(iPalette[2] + "");
            }
        } catch (Exception e) {
            iPalette[2] = -1;
            Rule2.setText(iPalette[2] + "");
        }
    }//GEN-LAST:event_Rule2FocusLost

    private void Rule4FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule4FocusLost
    {//GEN-HEADEREND:event_Rule4FocusLost
        try {
            iPalette[4] = Integer.parseInt(Rule4.getText());
            if (iPalette[4] > 0xFFFE) {
                iPalette[4] = 0xFFFE;
                Rule4.setText(iPalette[4] + "");
            }
        } catch (Exception e) {
            iPalette[4] = -1;
            Rule4.setText(iPalette[4] + "");
        }
    }//GEN-LAST:event_Rule4FocusLost

    private void Rule5FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule5FocusLost
    {//GEN-HEADEREND:event_Rule5FocusLost
        try {
            iPalette[5] = Integer.parseInt(Rule5.getText());
            if (iPalette[5] > 0xFFFE) {
                iPalette[5] = 0xFFFE;
                Rule5.setText(iPalette[5] + "");
            }
        } catch (Exception e) {
            iPalette[5] = -1;
            Rule5.setText(iPalette[5] + "");
        }
    }//GEN-LAST:event_Rule5FocusLost

    private void Rule6FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule6FocusLost
    {//GEN-HEADEREND:event_Rule6FocusLost
        try {
            iPalette[6] = Integer.parseInt(Rule6.getText());
            if (iPalette[6] > 0xFFFE) {
                iPalette[6] = 0xFFFE;
                Rule6.setText(iPalette[6] + "");
            }
        } catch (Exception e) {
            iPalette[6] = -1;
            Rule6.setText(iPalette[6] + "");
        }
    }//GEN-LAST:event_Rule6FocusLost

    private void Rule7FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule7FocusLost
    {//GEN-HEADEREND:event_Rule7FocusLost
        try {
            iPalette[7] = Integer.parseInt(Rule7.getText());
            if (iPalette[7] > 0xFFFE) {
                iPalette[7] = 0xFFFE;
                Rule7.setText(iPalette[7] + "");
            }
        } catch (Exception e) {
            iPalette[7] = -1;
            Rule7.setText(iPalette[7] + "");
        }
    }//GEN-LAST:event_Rule7FocusLost

    private void Rule8FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule8FocusLost
    {//GEN-HEADEREND:event_Rule8FocusLost
        try {
            iPalette[8] = Integer.parseInt(Rule8.getText());
            if (iPalette[8] > 0xFFFE) {
                iPalette[8] = 0xFFFE;
                Rule8.setText(iPalette[8] + "");
            }
        } catch (Exception e) {
            iPalette[8] = -1;
            Rule8.setText(iPalette[8] + "");
        }
    }//GEN-LAST:event_Rule8FocusLost

    private void Rule9FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule9FocusLost
    {//GEN-HEADEREND:event_Rule9FocusLost
        try {
            iPalette[9] = Integer.parseInt(Rule8.getText());
            if (iPalette[9] > 0xFFFE) {
                iPalette[9] = 0xFFFE;
                Rule9.setText(iPalette[9] + "");
            }
        } catch (Exception e) {
            iPalette[9] = -1;
            Rule9.setText(iPalette[9] + "");
        }
    }//GEN-LAST:event_Rule9FocusLost

    private void Rule0FocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_Rule0FocusLost
    {//GEN-HEADEREND:event_Rule0FocusLost
        try {
            iPalette[0] = Integer.parseInt(Rule0.getText());
            if (iPalette[0] > 0xFFFE) {
                iPalette[0] = 0xFFFE;
                Rule0.setText(iPalette[0] + "");
            }
        } catch (Exception e) {
            iPalette[0] = -1;
            Rule0.setText(iPalette[0] + "");
        }
    }//GEN-LAST:event_Rule0FocusLost

    private void PaletteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_PaletteActionPerformed
    {//GEN-HEADEREND:event_PaletteActionPerformed
        int j = 0;
        for (int i : iPalette) {
            if (i != -1) {
                j++;
            }
        }

        int[] iSet = new int[j];

        j = 0;
        for (int i : iPalette) {
            if (i != -1) {
                iSet[j] = i;
                j++;
            }
        }
        if (iSet.length > 0) {
            l.loadSet(iSet);
            AppScreen = new JScrollPane(l.createLattice());
            AppScreen.setPreferredSize(new Dimension(600, 579));
            AppSplit.setLeftComponent(AppScreen);
            Record.setSelected(false);
        }
    }//GEN-LAST:event_PaletteActionPerformed

    private void dRandomActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_dRandomActionPerformed
    {//GEN-HEADEREND:event_dRandomActionPerformed
        l.Load();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_dRandomActionPerformed

    private void SelfishActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelfishActionPerformed
    {//GEN-HEADEREND:event_SelfishActionPerformed
        l.LoadSelfish();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_SelfishActionPerformed

    private void SelflessActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SelflessActionPerformed
    {//GEN-HEADEREND:event_SelflessActionPerformed
        l.loadSelfless();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_SelflessActionPerformed

    private void PointSchemeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_PointSchemeActionPerformed
    {//GEN-HEADEREND:event_PointSchemeActionPerformed
        new Scheme(this, true).setVisible(true);
    }//GEN-LAST:event_PointSchemeActionPerformed

    private void FPSActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_FPSActionPerformed
    {//GEN-HEADEREND:event_FPSActionPerformed
        new FPS(this, true).setVisible(true);
    }//GEN-LAST:event_FPSActionPerformed

    private void RoundsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_RoundsActionPerformed
    {//GEN-HEADEREND:event_RoundsActionPerformed
        new Rounds(this, true).setVisible(true);
    }//GEN-LAST:event_RoundsActionPerformed

    private void ZinActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_ZinActionPerformed
    {//GEN-HEADEREND:event_ZinActionPerformed
        l.setZoomRelative(1);
    }//GEN-LAST:event_ZinActionPerformed

    private void ZoutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_ZoutActionPerformed
    {//GEN-HEADEREND:event_ZoutActionPerformed
        l.setZoomRelative(-1);
    }//GEN-LAST:event_ZoutActionPerformed

    private void FullScreenActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_FullScreenActionPerformed
    {//GEN-HEADEREND:event_FullScreenActionPerformed
        l.GoFS();
    }//GEN-LAST:event_FullScreenActionPerformed

    private void SaveAsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveAsActionPerformed
    {//GEN-HEADEREND:event_SaveAsActionPerformed
        Pdg.showSaveDialog(this, l);
    }//GEN-LAST:event_SaveAsActionPerformed

    private void OpenActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_OpenActionPerformed
    {//GEN-HEADEREND:event_OpenActionPerformed
        l = Pdg.showOpenLattice(iPalette, this);
        this.updateRuleGUI();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_OpenActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveActionPerformed
    {//GEN-HEADEREND:event_SaveActionPerformed
        if (Pdg.getSelectedFile().exists()) {
            if (Pdg.SavePca(l)) {
                JOptionPane.showMessageDialog(this, Pdg.getSelectedFile().
                        toString() + " was successfully saved");
            }
            else {
                JOptionPane.showMessageDialog(this, Pdg.getSelectedFile().
                        toString() + " save failed.");
            }
        }
        else {
            SaveAs.doClick();
        }
    }//GEN-LAST:event_SaveActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_ExitActionPerformed
    {//GEN-HEADEREND:event_ExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void SaveScreenActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveScreenActionPerformed
    {//GEN-HEADEREND:event_SaveScreenActionPerformed
        Pdg.showSaveImgDialog(this, l);
    }//GEN-LAST:event_SaveScreenActionPerformed

    private void PointViewActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_PointViewActionPerformed
    {//GEN-HEADEREND:event_PointViewActionPerformed
        if (PointView.isSelected()) {
            l.setPointMode(true);
        }
        else {
            l.setPointMode(false);
        }
    }//GEN-LAST:event_PointViewActionPerformed

    private void ImportActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_ImportActionPerformed
    {//GEN-HEADEREND:event_ImportActionPerformed
        l = Pdg.showImportLattice(iPalette, this);
        this.updateRuleGUI();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_ImportActionPerformed

    private void OneMemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_OneMemActionPerformed
    {//GEN-HEADEREND:event_OneMemActionPerformed
        l.Loadmem1();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_OneMemActionPerformed

    private void TwoMemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_TwoMemActionPerformed
    {//GEN-HEADEREND:event_TwoMemActionPerformed
        l.Loadmem2();
        AppScreen = new JScrollPane(l.createLattice());
        AppScreen.setPreferredSize(new Dimension(600, 579));
        AppSplit.setLeftComponent(AppScreen);
        Record.setSelected(false);
    }//GEN-LAST:event_TwoMemActionPerformed

    private void RecordActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_RecordActionPerformed
    {//GEN-HEADEREND:event_RecordActionPerformed
        if (Record.isSelected()) {
            if (FirstMoves.isSelected()) {
                l.setStats(new DvsCStats(l));
            }
            else if (SpecificPalette.isSelected()) {
                int j = 0;
                for (int i : iPalette) {
                    if (i != -1) {
                        j++;
                    }
                }

                int[] iSet = new int[j];

                j = 0;
                for (int i : iPalette) {
                    if (i != -1) {
                        iSet[j] = i;
                        j++;
                    }
                }
                if (iSet.length > 0) {
                    l.setStats(new PaletteStats(l, iSet));
                }
                else {
                    Record.setSelected(false);
                }
            }
            else if (HammingDistance.isSelected()) {
                l.setStats(new HammingDistanceStats(l));
            }
            else if (DNA.isSelected()) {
                l.setStats(new BitStats(l));
            }
            else if (TotalPoints.isSelected()) {
                l.setStats(new PointsStats(l));
            }
            else {
                Record.setSelected(false);
                JOptionPane.showMessageDialog(this, "Select something to record first.");
            }

        }
        else {
            l.setStats(null);
        }
    }//GEN-LAST:event_RecordActionPerformed

    private void FirstMovesActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_FirstMovesActionPerformed
    {//GEN-HEADEREND:event_FirstMovesActionPerformed
        if(Record.isSelected())
        {
            Record.setSelected(false);
            Record.doClick();
        }
    }//GEN-LAST:event_FirstMovesActionPerformed

    private void SpecificPaletteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SpecificPaletteActionPerformed
    {//GEN-HEADEREND:event_SpecificPaletteActionPerformed
        if(Record.isSelected())
        {
            Record.setSelected(false);
            Record.doClick();
        }
    }//GEN-LAST:event_SpecificPaletteActionPerformed

    private void HammingDistanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_HammingDistanceActionPerformed
    {//GEN-HEADEREND:event_HammingDistanceActionPerformed
        if(Record.isSelected())
        {
            Record.setSelected(false);
            Record.doClick();
        }
    }//GEN-LAST:event_HammingDistanceActionPerformed

    private void DNAActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_DNAActionPerformed
    {//GEN-HEADEREND:event_DNAActionPerformed
        if(Record.isSelected())
        {
            Record.setSelected(false);
            Record.doClick();
        }
    }//GEN-LAST:event_DNAActionPerformed

    private void TotalPointsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_TotalPointsActionPerformed
    {//GEN-HEADEREND:event_TotalPointsActionPerformed
        if(Record.isSelected())
        {
            Record.setSelected(false);
            Record.doClick();
        }
    }//GEN-LAST:event_TotalPointsActionPerformed

    private void SaveStxtActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_SaveStxtActionPerformed
    {//GEN-HEADEREND:event_SaveStxtActionPerformed
        Pdg.showSaveStatsDialog(this, l);
    }//GEN-LAST:event_SaveStxtActionPerformed

    private void AutoTestActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_AutoTestActionPerformed
    {//GEN-HEADEREND:event_AutoTestActionPerformed
        new TestLoader(this, l).test();
    }//GEN-LAST:event_AutoTestActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {

            public void run()
            {
                new AppFrame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar AppBar;
    private javax.swing.JPanel AppControl;
    private javax.swing.JScrollPane AppScreen;
    private javax.swing.JSplitPane AppSplit;
    private javax.swing.JMenuItem AutoTest;
    private javax.swing.JRadioButtonMenuItem DNA;
    private javax.swing.JMenuItem Exit;
    private javax.swing.JMenuItem FPS;
    private javax.swing.JMenu File;
    private javax.swing.JRadioButtonMenuItem FirstMoves;
    private javax.swing.JMenuItem FullScreen;
    private javax.swing.JRadioButtonMenuItem HammingDistance;
    private javax.swing.JMenuItem Import;
    private javax.swing.JMenuItem OneMem;
    private javax.swing.JMenuItem Open;
    private javax.swing.JMenu Options;
    private javax.swing.JMenuItem Palette;
    private javax.swing.JMenuItem PointScheme;
    private javax.swing.JCheckBoxMenuItem PointView;
    private javax.swing.JCheckBoxMenuItem Record;
    private javax.swing.JMenuItem Rounds;
    private javax.swing.JTextField Rule0;
    private javax.swing.JTextField Rule1;
    private javax.swing.JTextField Rule2;
    private javax.swing.JTextField Rule3;
    private javax.swing.JTextField Rule4;
    private javax.swing.JTextField Rule5;
    private javax.swing.JTextField Rule6;
    private javax.swing.JTextField Rule7;
    private javax.swing.JTextField Rule8;
    private javax.swing.JTextField Rule9;
    private javax.swing.JTextArea RuleText;
    private javax.swing.JMenuItem Save;
    private javax.swing.JMenuItem SaveAs;
    private javax.swing.JMenuItem SaveScreen;
    private javax.swing.JMenuItem SaveStxt;
    private javax.swing.JMenuItem Selfish;
    private javax.swing.JMenuItem Selfless;
    private javax.swing.JRadioButtonMenuItem SpecificPalette;
    private javax.swing.JMenu Statistics;
    private javax.swing.ButtonGroup StatsButtons;
    private javax.swing.JTextArea StatsText;
    private javax.swing.JRadioButtonMenuItem TotalPoints;
    private javax.swing.JMenuItem TwoMem;
    private javax.swing.JMenuItem WidthHeight;
    private javax.swing.JMenuItem Zin;
    private javax.swing.JMenuItem Zout;
    private javax.swing.JMenuItem dRandom;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    // End of variables declaration//GEN-END:variables
}
