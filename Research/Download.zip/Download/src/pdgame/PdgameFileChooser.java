/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */
package pdgame;

import display.RuleDisplay;
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

/**
 * This opens and saves files for the PDGame application.
 *
 * @author Brian
 */
public class PdgameFileChooser extends JFileChooser
{

    private DataOutputStream out;
    private DataInputStream in;
    private File f = null;
    private FileFilter fs = new FileFilter()
    {
        @Override
        public boolean accept(File f)
        {
            if (f.isDirectory()) {
                return true;
            }

            if (f.getAbsolutePath().endsWith(".pca")) {
                return true;
            }
            return false;
        }

        @Override
        public String getDescription()
        {
            return ("*.pca Prisoner's Dilemna CA file");
        }
    };
    private FileFilter fcsv = new FileFilter()
    {
        @Override
        public boolean accept(File f)
        {
            if (f.isDirectory()) {
                return true;
            }

            if (f.getAbsolutePath().endsWith(".csv")) {
                return true;
            }
            return false;
        }

        @Override
        public String getDescription()
        {
            return ("*.csv comma-separated values");
        }
    };
    private FileFilter fpng = new FileFilter()
    {
        @Override
        public boolean accept(File f)
        {
            if (f.isDirectory()) {
                return true;
            }

            if (f.getAbsolutePath().endsWith(".png")) {
                return true;
            }
            return false;
        }

        @Override
        public String getDescription()
        {
            return ("*.png portable network graphics");
        }
    };

    public PdgameFileChooser()
    {
    }

    public void showFolderDialog(Component parent)
    {
        this.setFileSelectionMode(PdgameFileChooser.DIRECTORIES_ONLY);
        if (this.showOpenDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            JOptionPane.showMessageDialog(this,
                    "All files will be saved in the directory: " + this.
                    getSelectedFile().
                    toString());
        }
        this.setCurrentDirectory(this.getSelectedFile());
        this.setFileSelectionMode(PdgameFileChooser.FILES_ONLY);
    }

    public void showSaveDialog(Component parent, Lattice l)
    {
        this.setFileFilter(fs);

        if (this.showSaveDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            if (this.SavePca(l)) {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " was successfully saved");
            }
            else {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " save failed.");
            }
        }
        else {
            this.setSelectedFile(null);
        }

    }

    public void showSaveImgDialog(Component parent, Lattice l)
    {
        this.setFileFilter(fpng);
        if (this.showSaveDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            if (this.SavePcaImage(l)) {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " was successfully saved");
            }
            else {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " save failed.");
            }
        }
        else {
            this.setSelectedFile(null);
        }
    }

    public void showSaveStatsDialog(Component parent, Lattice l)
    {
        this.setFileFilter(fcsv);
        if (this.showSaveDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            if (this.saveStats(l.getStats().toString())) {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " was successfully saved");
            }
            else {
                JOptionPane.showMessageDialog(this, this.getSelectedFile().
                        toString() + " save failed.");
            }
        }
        else {
            this.setSelectedFile(null);
        }
    }

    @Override
    public int showSaveDialog(Component parent)
    {
        int i;
        while ((i = super.showSaveDialog(this))
                == PdgameFileChooser.APPROVE_OPTION && this.getSelectedFile().
                exists() && !(JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to overwrite: " + this.getSelectedFile().
                toString()) == JOptionPane.OK_OPTION));
        return i;
    }

    @Override
    public int showOpenDialog(Component parent)
    {
        int i;
        while ((i = super.showOpenDialog(parent))
                == PdgameFileChooser.APPROVE_OPTION && !this.getSelectedFile().
                exists());
        return i;
    }

    public Lattice showOpenLattice(int[] iPalette, AppFrame parent)
    {
        this.setFileFilter(fs);

        if (this.showOpenDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            return LoadPca(iPalette, parent);
        }

        return new Lattice(iPalette, parent);
    }

    public Lattice showImportLattice(int[] iPalette, AppFrame parent)
    {
        this.setFileFilter(fpng);

        if (this.showOpenDialog(parent) == PdgameFileChooser.APPROVE_OPTION) {
            return ImportPca(iPalette, parent);
        }

        return new Lattice(iPalette, parent);

    }

    /**
     * Writes to the file stored in FileExtractor a string.
     *
     * @param s Text to be written to a file.
     */
    public boolean saveStats(String s)
    {
        try {
            if (!this.getSelectedFile().toString().endsWith(".csv")) {
                this.setSelectedFile(new File(this.getSelectedFile().toString()
                        + ".csv"));

                String sLines[] = s.split("\n");
                FileOutputStream fos = new FileOutputStream(
                        this.getSelectedFile(), false);
                BufferedOutputStream bos = new BufferedOutputStream(fos);
                PrintWriter pw = new PrintWriter(bos);

                for (String sline : sLines) {
                    pw.println(sline);
                }

                pw.close();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean SavePcaImage(Lattice l)
    {
        try {
            if (!this.getSelectedFile().toString().endsWith(".png")) {
                this.setSelectedFile(new File(this.getSelectedFile().toString()
                        + ".png"));
            }
            ImageIO.write(l.getImage(), "png", this.getSelectedFile());
            return true;

        } catch (Exception e) {
            return false;
        }

    }

    public boolean SavePca(Lattice l)
    {
        if (l == null) {
            return false;
        }

        if (!this.getSelectedFile().toString().endsWith(".pca")) {
            this.setSelectedFile(new File(this.getSelectedFile().toString()
                    + ".pca"));
        }

        try {
            out =
                    new DataOutputStream(new BufferedOutputStream(new FileOutputStream(this.
                    getSelectedFile())));

            int iP[] = l.getPalette();
            for (int y : iP) {
                out.writeInt(y);
            }

            out.writeInt(l.getWidthHeight()[0]);
            out.writeInt(l.getWidthHeight()[1]);

            out.writeInt(l.getRounds());

            int iS[][] = l.getScheme();
            for (int x[] : iS) {
                for (int y : x) {
                    out.writeInt(y);
                }
            }


            int q = 0;
            int iL[][][] = l.getLattice();
            for (int x[][] : iL) {
                for (int y[] : x) {
                    for (int z : y) {
                        out.writeInt(z);
                        q++;
                    }
                }
            }

            out.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Lattice ImportPca(int[] iPalette, AppFrame parent)
    {
        try {
            BufferedImage bi = ImageIO.read(this.getSelectedFile());
            Lattice l = new Lattice(iPalette, parent);

            l.setWidthHeight(bi.getWidth(), bi.getHeight());
            int[][][] iL = new int[bi.getWidth()][bi.getHeight()][3];

            for (int x = 0; x < iL.length; x++) {
                for (int y = 0; y < iL[x].length; y++) {
                    iL[x][y][0] = RuleDisplay.ruleFromPixel(bi.getRGB(x, y));
                    iL[x][y][1] = 0;
                    iL[x][y][2] = RuleDisplay.ruleFromPixel(bi.getRGB(x, y));
                }
            }
            l.loadSet(iL);

            return l;
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, this.getSelectedFile().
                    toString() + " failed to load.");
            return new Lattice(iPalette, parent);
        }

    }

    public Lattice LoadPca(int[] iPalette, AppFrame parent)
    {
        try {
            in =
                    new DataInputStream(new BufferedInputStream(new FileInputStream(this.
                    getSelectedFile())));
            Lattice l = new Lattice(iPalette, parent);

            for (int i = 0; i < iPalette.length; i++) {
                int j = in.readInt();
                iPalette[i] = j;
            }

            l.setWidthHeight(in.readInt(), in.readInt());

            l.setRounds(in.readInt());

            l.setScheme(new int[][]{{in.readInt(), in.readInt()}, {in.readInt(),
                            in.
                            readInt()}});

            int iL[][][] =
                    new int[l.getWidthHeight()[0]][l.getWidthHeight()[1]][3];
            for (int x = 0; x < iL.length; x++) {
                for (int y = 0; y < iL[x].length; y++) {
                    for (int z = 0; z < iL[x][y].length; z++) {
                        iL[x][y][z] = in.readInt();
                    }
                }
            }
            l.loadSet(iL);

            in.close();
            return l;
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, this.getSelectedFile().
                    toString() + " failed to load.");
            return new Lattice(iPalette, parent);
        }
    }
}
