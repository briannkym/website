/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */

package pdgame;

import display.Display;
import display.PointDisplay;
import display.RuleDisplay;
import img.iInterface;
import img.iProjector;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import stats.NullStats;
import stats.Stats;

/**
 * The lattice simply passes on commands to the pdAlgorithm object, and interfaces
 * with the animation loop. Using the Facade pattern, it hopes to take the complicated
 * bits out of the main GUI. Here's an example for how to use it(taken from AppFrame):
 *
 *      Lattice l = new Lattice(iPalette, this);
 *      l.loadSelfless();
 *      AppScreen=new JScrollPane(l.createLattice());
 *      AppScreen.setPreferredSize(new Dimension(600,579));
 *      AppSplit.setLeftComponent(AppScreen);
 *
 * @author Brian
 * @see pdAlgorithm for more information on how the actual algorithm works.
 * @see AppFrame for how this class is used.
 */
public class Lattice implements iInterface
{

    //The default width and height of a lattice.
    private int iWidth = 300, iHeight = 300;
    //A pointer to the lattice of cells.
    private int[][][] iLattice;
    //The default point scheme.
    private int[][] iScheme = {{1, 5}, {0, 3}};
    //The default number of rounds.
    private int iRounds = 4;
    //The default number of frames per second.
    private float fps = 5.0f;
    //The defauly zoom in on the cells.
    private int iZoom = 1;
    //The object that controls the animation thread.
    private iProjector ip;
    //The BufferedImage updated for the animation.
    private BufferedImage bi;
    //The current index of the Palette.
    private int iPaletteIndex = 0;
    //A palette with 10 different rule numbers.
    private int[] iPalette;
    //The parent GUI
    private AppFrame Parent;
    //The Jpanel to run the animation on.
    private JPanel jp;
    //The algorithm object.
    private pdAlgorithm pdA;
    //The many different states the screen can be in, and a check for the Palette.
    private boolean bDrawMode = false, bPaused = false, bPalette = false, bPointMode =
            false, bTestMode = false;
    //Random number generator.
    private Random r = new Random();
    //The number of Rounds done.
    private int iNumRound = 0;
    //A Stats Object for keeping track of the lattice.
    Stats s = new NullStats();
    //The way to display the Lattice.
    Display d = new RuleDisplay();
    //Testing related variables
    private List<Test> tests;
    private String sFile;
    private int iLength;
    private int iNumber = 0;
    private int[] iFreeze;
    public String sInitial;
    public String sStat;
    private PdgameFileChooser Pdg;

    /**
     * Initiates the Lattice with a Palette of rule numbers (whish the GUI can update)
     * And the parent class in order to communicate backwards.
     * @param iPalette The Palette of rules, should have length of 10.
     * @param Parent Te parent component.
     */
    public Lattice(int[] iPalette, AppFrame Parent)
    {
        this.iPalette = iPalette;
        this.Parent = Parent;
    }

    /**
     * Updates the lattice, called from the animation loop. The bufferedImage is
     * simply the pointer to be updated, just in case the interfaced class doesn't
     * have access to the original image.
     * @param ISlide The Slide to be projected.
     */
    @Override
    public void iUpdate(BufferedImage ISlide)
    {
        if (!(bDrawMode || bPaused)) {
            pdA.updateLattice(); //If we're not paused or drawing, update rules!
            s.updateStats();
            Parent.writeStats(s.getSummary());
            iNumRound++;
        }

        int iHigh = 0;
        for (int x[] : iScheme) {
            for (int y : x) {
                iHigh = (y > iHigh) ? y : iHigh; //Find the most points possible in a round.
            }
        }

        d.draw(bi, iLattice, iHigh * iRounds);
        if (bTestMode) {
            if (iFreeze != null) {
                for (int i : iFreeze) {
                    if (iNumRound == i) {
                        Pdg.setSelectedFile(new File(Pdg.getCurrentDirectory(), sFile
                                + "_" + iNumber + "_r" + iNumRound));
                        Pdg.SavePcaImage(this);
                    }
                }
            }
            if (iNumRound == iLength) {
                Pdg.setSelectedFile(new File(Pdg.getCurrentDirectory(), sFile
                        + "_" + iNumber + "_" + iNumRound));
                Pdg.SavePcaImage(this);
                Pdg.setSelectedFile(new File(Pdg.getCurrentDirectory(), sFile
                        + "_" + iNumber + "_" + iNumRound));
                Pdg.saveStats(s.toString());
                testIteration();
            }
        }
    }

    /**
     * Turn pointMode drawing on and off. True = on. False= off.
     * @param bPointMode True = on.
     */
    public void setPointMode(boolean bPointMode)
    {
        if (bPointMode) {
            d = new PointDisplay();
        }
        else {
            d = new RuleDisplay();
        }
    }

    /**
     * Load in a completely random lattice (with all possible rules)
     */
    public void Load()
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iRule = (r.nextInt(0x8000)) << 1;
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Randomly load in cells with memory of 1.
     */
    public void Loadmem1()
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iR = (r.nextInt(8));
                int iRule = 0;
                for (int i = 3; i < 14; i += 2) {
                    iRule |= ((iR & 6) << i);
                }
                iRule |= (iR << 1);
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Randomly load in cells with memory of 2.)
     */
    public void Loadmem2()
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iR = (r.nextInt(128));
                int iRule = ((iR & 120) << 9) | ((iR & 120) << 5) | (iR << 1);
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Load in a completely random lattice (with all initial defectors)
     */
    public void LoadSelfish()
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iRule = (r.nextInt(0x7fff)) << 2; //Initial move will be 0.
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Load in a completely random lattice (with all initial cooperators)
     */
    public void loadSelfless()
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iRule = ((r.nextInt(0x7fff)) << 2) | 2; //First move = Cooperate.
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Load in a set of rules randomly into the lattice.
     * @param iSet the different rules to be loaded in.
     */
    public void loadSet(int[] iSet)
    {
        iNumRound = 0;
        setStats(null);
        iLattice = new int[iWidth][iHeight][3];
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iRule = iSet[r.nextInt(iSet.length)];
                iLattice[x][y][0] = iRule;
                iLattice[x][y][1] = 0;
                iLattice[x][y][2] = iRule;
            }
        }
    }

    /**
     * Load an entire lattice in.
     * @param iLattice the lattice to load in, see pdAlgorithm for format.
     */
    public void loadSet(int[][][] iLattice)
    {
        iNumRound = 0;
        setStats(null);
        this.iLattice = iLattice;
    }

    /**
     * !IMPORTANTE! Make sure to use one of the Load methods before using createLattice,
     * otherwise you will get an error. Once the lattice is loaded, this method creates
     * the animation projected onto a JPanel.
     *
     * The JPanel also has several listeners:
     * Left Click: Play/Pause. I you hold a number (0-9) on the keyboard, this will
     * draw in that rule corresponding to the number on the palette.
     *
     * Right Click: Exit FullScreen, or Show Stats on a rule.
     *
     * @return the Jpanel with the animation.
     */
    public JPanel createLattice()
    {
        if (ip != null) {
            endSimulation();
        }
        if (!bTestMode) {
            bPaused = true;
        }
        pdA = new pdAlgorithm(iLattice, iRounds, iScheme);
        bi = new BufferedImage(iWidth, iHeight, BufferedImage.TYPE_INT_ARGB);
        ip = new iProjector(fps, bi, "PD Lattice", this);
        jp = ip.init(new Dimension(iZoom * iWidth, iZoom * iHeight));

        jp.addMouseListener(new MouseListener()
        {

            public void mouseClicked(MouseEvent e)
            {
            }

            public void mousePressed(MouseEvent e)
            {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (bPalette) {
                        bDrawMode = true;
                        if (!ip.isRunning()) {
                            ip.resume();
                        }
                        int x = e.getX() * iWidth / jp.getWidth();
                        int y = e.getY() * iHeight / jp.getHeight();
                        if (x >= 0 && x < iWidth && y >= 0 && y < iHeight) {
                            iLattice[x][y][0] = iPalette[iPaletteIndex];
                            iLattice[x][y][1] = 0;
                            iLattice[x][y][2] = iPalette[iPaletteIndex];
                        }
                    }
                    else {
                        bDrawMode = false;
                        bPaused = !bPaused;
                    }
                }
                if (e.getButton() == MouseEvent.BUTTON3) {
                    if (ip.isFS()) {
                        ip.closeFS();
                        ip.resume();
                        Parent.setPanel(jp);
                    }
                    else {
                        int x = e.getX() * iWidth / jp.getWidth();
                        int y = e.getY() * iHeight / jp.getHeight();
                        if (x >= 0 && x < iWidth && y >= 0 && y < iHeight) {
                            Parent.writeRuleText(iLattice[x][y]);
                        }
                    }
                }
            }

            public void mouseReleased(MouseEvent e)
            {
            }

            public void mouseEntered(MouseEvent e)
            {
                jp.requestFocusInWindow();
                ip.resume();
            }

            public void mouseExited(MouseEvent e)
            {
                if (!bTestMode) {
                    ip.stop();
                }
            }
        });

        jp.addMouseMotionListener(new MouseMotionListener()
        {

            public void mouseDragged(MouseEvent e)
            {
            }

            public void mouseMoved(MouseEvent e)
            {
            }
        });

        jp.addMouseWheelListener(new MouseWheelListener()
        {

            public void mouseWheelMoved(MouseWheelEvent e)
            {
                setZoomRelative(e.getWheelRotation());
            }
        });

        jp.addKeyListener(new KeyListener()
        {

            public void keyTyped(KeyEvent e)
            {
            }

            public void keyPressed(KeyEvent e)
            {

                bPalette = true;
                switch (e.getKeyCode()) {
                    case (KeyEvent.VK_0): {
                        iPaletteIndex = 0;
                        break;
                    }
                    case (KeyEvent.VK_1): {
                        iPaletteIndex = 1;
                        break;
                    }
                    case (KeyEvent.VK_2): {
                        iPaletteIndex = 2;
                        break;
                    }
                    case (KeyEvent.VK_3): {
                        iPaletteIndex = 3;
                        break;
                    }
                    case (KeyEvent.VK_4): {
                        iPaletteIndex = 4;
                        break;
                    }
                    case (KeyEvent.VK_5): {
                        iPaletteIndex = 5;
                        break;
                    }
                    case (KeyEvent.VK_6): {
                        iPaletteIndex = 6;
                        break;
                    }
                    case (KeyEvent.VK_7): {
                        iPaletteIndex = 7;
                        break;
                    }
                    case (KeyEvent.VK_8): {
                        iPaletteIndex = 8;
                        break;
                    }
                    case (KeyEvent.VK_9): {
                        iPaletteIndex = 9;
                        break;
                    }
                    default: {
                        bPalette = false;
                        break;
                    }
                }
            }

            public void keyReleased(KeyEvent e)
            {
                bPalette = false;
            }
        });

        return jp;

    }

    /**
     * Turns on testing mode. 
     * @param tests
     */
    public void testMode(List<Test> tests)
    {
        try {
            this.tests = tests;
            bTestMode = true;
            Pdg = new PdgameFileChooser();
            Pdg.showFolderDialog(Parent);
            testIteration();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void testIteration()
    {
        if (iNumber == 0) {
            if (!tests.isEmpty()) {
                Test t = tests.remove(0);
                this.iFreeze = t.iFreeze;
                this.iHeight = t.iHeight;
                this.iWidth = t.iWidth;
                this.iRounds = t.iRounds;
                this.iLength = t.iLength;
                this.iScheme = t.iScheme;
                this.iNumber = t.iNumber;
                this.sFile = t.sFileName;
                this.sInitial = t.sInitial;
                this.sStat = t.sStat;
                Parent.newSim(sInitial);
                Parent.newStat(sStat);
                Pdg.setSelectedFile(new File(Pdg.getCurrentDirectory(), sFile
                        + "_" + iNumber));
                Pdg.SavePca(this);
            }
            else {
                bTestMode = false;
                JOptionPane.showMessageDialog(Parent, "The tests are Completed");
            }
        }
        else {
            iNumber--;
            Parent.newSim(sInitial);
            Parent.newStat(sStat);
            Pdg.setSelectedFile(new File(Pdg.getCurrentDirectory(), sFile + "_"
                    + iNumber));
            Pdg.SavePca(this);
        }

    }

    /**
     * Projects images to the full screen.
     */
    public void GoFS()
    {
        if (ip != null) {
            JFrame jf = new JFrame();
            ip.init(jf);
        }
    }

    /**
     * Just in case someone needs it, this stops the simulation permanently,
     * dereferencing the projector.
     */
    public void endSimulation()
    {
        ip.stop();
        ip = null;
    }

    /**
     * Increases or Decreases the zoom on the projected image (lattice).
     * @param iZMove Positive = zoom in, or add to zoom.
     */
    public void setZoomRelative(int iZMove)
    {
        iZoom += iZMove;
        if (iZoom > 10) {
            iZoom = 10;
        }
        if (iZoom < 1) {
            iZoom = 1;
        }

        jp.setSize(new Dimension(iZoom * iWidth, iZoom
                * iHeight));
        jp.setPreferredSize(new Dimension(iZoom * iWidth, iZoom
                * iHeight));
    }

    /**
     * Change the rounds on the fly. Updates the Algorithm object.
     * @param iRounds new number of rounds, suggested [1, 20].
     */
    public void setRounds(int iRounds)
    {
        this.iRounds = iRounds;
        if (pdA != null) {
            pdA.setRounds(iRounds);
        }
    }

    /**
     * Gives back the rounds that each cell plays.
     * @return the rounds.
     */
    public int getRounds()
    {
        return iRounds;
    }

    /**
     * Sets the width and height for the NEXT simulation. It's unclear what the user
     * would want  to fill in to the lattice if we resized on the fly.
     * @param iWidth the new width.
     * @param iHeight the new height.
     */
    public void setWidthHeight(int iWidth, int iHeight)
    {
        this.iWidth = iWidth;
        this.iHeight = iHeight;
    }

    /**
     * Gives back the current width and height.
     * @return [0]=width , [1]=height.
     */
    public int[] getWidthHeight()
    {
        int[] i = {iWidth, iHeight};
        return i;
    }

    /**
     * Sets a new scheme. Make sure is is in the form {{1, 5}, {0, 3}}.
     * @param iScheme in the form {{DD, DC}, {CD, CC}}.
     */
    public void setScheme(int[][] iScheme)
    {
        this.iScheme = iScheme;
        if (pdA != null) {
            pdA.setScheme(iScheme);
        }
    }

    /**
     * Gives the current point scheme back.
     */
    public int[][] getScheme()
    {
        return iScheme;
    }

    /**
     * Changes the Frames per second on the fly.
     * @param fps the new frames per second value.
     */
    public void setFPS(float fps)
    {
        this.fps = fps;
        ip.setFPS(fps);
    }

    /**
     * Gives the entire lattice back. Useful for gathering statistics.
     * @return the lattice. See pdAlgorithm to learn more about the Lattice.
     */
    public int[][][] getLattice()
    {
        return iLattice;
    }

    /**
     * Gives the currently used Palette, for backwards compatability with the
     * AppFrame
     * @return the current Palette in use.
     */
    public int[] getPalette()
    {
        return iPalette;
    }

    /**
     * The current image of the lattice being projected.
     * @return An image of the lattice.
     */
    public BufferedImage getImage()
    {
        return bi;
    }

    /**
     * Gives back the current round played.
     * @return The current round.
     */
    public int getRound()
    {
        return iNumRound;
    }

    /**
     * Use this method to add or remove a statistical measure to the lattice.
     * @see Stats
     * @param s The stats you want to use.
     */
    public void setStats(Stats s)
    {
        if (s != null) {
            this.s = s;
        }
        else {
            this.s = new NullStats();
        }
    }

    /**
     * Gets the stats that the lattice is using.
     * @return The current Stats.
     */
    public Stats getStats()
    {
        return s;
    }
}
