package pdgame;

/**
 * This class attempts to hide the complicated procedure of playing the iterated
 * prisoner's Dilemma game, updating an int array passed in to the constructor.
 * The constructor takes in an array with the following form int[width][height][3].
 * The algorithm needs to hold 3 int for each rule, one representing the current rule,
 * one representing the current points, and one representing the next rule.
 *
 * Here's an example of how to use this code:
 *
 *    pdAlgorithm pdA = new pdAlgorithm(iLattice, iRounds, iScheme);
 *    for(int i=0; i< 20; i++) //Does 20 iterations
 *    {
 *      pdA.updateLattice();
 *    }
 *
 *    //Optional
 *    pdA.setRounds(10); //Change the number of rounds each cell plays on the fly.
 *    pdA.setScheme({{2,4},{0,2}}); //Changes the point scheme.
 *
 * @author Brian
 */
public class pdAlgorithm
{
    /* The lattice, with 3 spaces for the current rule, one representing the
     * current points, and one representing the next rule. Should be in the format
     * int[width][height][3].
     */
    private int[][][] iLattice;

    //The number of rounds(or iterations) that each cell plays with eachother.
    private int iRounds;

    /*
     * The scheme of the points. The prisoner's dilemma game is commonly played
     * using this scheme: {{1, 5}, {0, 3}}. Should be in the form {{DD, DC, CD, CC}}
     * where the defector has a possible 1 or 5 points, and the cooperator has 0
     * or 3.
     */
    private int[][] iScheme;

    /**
     * Instantiates with a lattice, and a certain number of rounds as well as a scheme.
     * Rules can be set for a position x,y in the array like so int[x][y][2]= rule_number.
     * The array you pass in will update itself, and should not be messed with or changed.
     *
     * @param iLattice Should be in the form int[width][height][3].
     * @param iRounds The number of rounds.
     * @param iScheme A point scheme for playing the game Ex: {{1, 5}, {0, 3}}.
     */
    public pdAlgorithm(int[][][] iLattice, int iRounds, int[][] iScheme)
    {
        this.iLattice = iLattice;
        this.iRounds = iRounds;
        this.iScheme=iScheme;
    }

    /**
     * Updates the lattice by updating the rules, and playing for points,
     * setting the next rule as well.
     */
    public void updateLattice()
    {
        /*
         * The next rule is kept in iLattice[x][y][2], the current rule is in
         * iLattice[x][y][0]. Simply copies the next rule into the current one, and
         * sets the points, iLattice[x][y][1], equal to zero.
         */
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                iLattice[x][y][0]=iLattice[x][y][2];
                iLattice[x][y][1]=0;
            }
        }

        /*
         * In order to play the game with each cell in a Moore lattice, a cell
         * only has to play with half of them, while keeping track of the points it
         * gained from playing with the cells it has not played with.
         */
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int xMinus = (x + iLattice.length - 1) % iLattice.length;
                int xPlus = (x + 1) % iLattice.length;
                int yPlus = (y + 1) % iLattice[x].length;

                /*
                 * 0 0 0
                 * 0 x 1
                 * 1 1 1
                 *
                 * Plays with the four 1's in the Moore lattice pictured above.
                 */
                playGame(iLattice[x][y], iLattice[xMinus][yPlus]);
                playGame(iLattice[x][y], iLattice[x][yPlus]);
                playGame(iLattice[x][y], iLattice[xPlus][yPlus]);
                playGame(iLattice[x][y], iLattice[xPlus][y]);
            }
        }

        /*
         * This checks the points of the neighboring cells to see which one to update
         * to.
         */
        for (int x = 0; x < iLattice.length; x++) {
            for (int y = 0; y < iLattice[x].length; y++) {
                int iHigh=0;
                int iHighRule=iLattice[x][y][0]; //Initially, the winning rule is the rule's own.
                for (int lx = -1; lx < 2; lx++) {
                    for (int ly = -1; ly < 2; ly++) {
                        int iX = (x + iLattice.length + lx) % iLattice.length;
                        int iY = (y + iLattice[x].length + ly) % iLattice[x].length;
                        if(iLattice[iX][iY][1]>iHigh){ //If the checked rule has more points
                            iHigh=iLattice[iX][iY][1];
                            iHighRule=iLattice[iX][iY][0];
                        }
                        /*
                         * else if the checked rule has the same ammount of points and is
                         * not the same rule as the current high rule (basically, there's
                         * a tie), then keep the original rule.
                         */
                        else if((iLattice[iX][iY][1]==iHigh)&&(iLattice[iX][iY][0]!=iHighRule))
                        {
                            iHighRule=iLattice[x][y][0];
                        }
                    }
                }

                //Set the next rule to whatever the highrule is.
                iLattice[x][y][2]=iHighRule;
            }
        }
    }

    /**
     * Change the number of round(iterations) the cells play.
     * @param iRounds new number of rounds, suggested [1, 20].
     */
    public void setRounds(int iRounds)
    {
        this.iRounds=iRounds;
    }

    /**
     * Change the point scheme for how cells earn points.
     * @param iScheme new point scheme. Ex: {{1, 5}, {0, 3}}
     */
    public void setScheme(int[][] iScheme)
    {
        this.iScheme=iScheme;
    }

    /**
     * Plays a game between two cells. Each cell should have it's current rule in
     * the i1[0] position, and its points in i1[1]. This method basically adds to
     * the points, i1[1], of both cells.
     * @param i1 First cell int array to play.
     * @param i2 Second cell int array to play.
     */
    private void playGame(int[] i1, int[] i2)
    {
        //This is the next move the cell will do.
        int iP1Hnext = 0;
        int iP2Hnext = 0;

        /**
         * This algorithm expects rules(in an int) to look like the following:
         * Position(base 2) Value
         * 0 0 0 0          Don't Care
         * 0 0 0 1          The first move 1 = cooperate, 0 = defect.
         * 0 0 1 0          The Second move if opponent defected.
         * 0 0 1 1          The Second move if opponent cooperated.
         * 0 1 0 0          The third move if opponent defected twice.
         * 0 1 0 1          If opponent defected then cooperated.
         * 0 1 1 0          If opponent cooperated then defected.
         * 0 1 1 1          If opponent defected twice.
         * 1 0 0 0          The fourth move if opponent defected thrice.
         * 1 0 0 1          If opponent defected x2 then cooperated.
         * 1 0 1 0          If opponent defected, cooperated, then defected.
         * 1 0 1 1          If opponent defected then cooperated x2.
         * 1 1 0 0          If opponent cooperated then defected x2.
         * 1 1 0 1          If opponent cooperated, defected, then cooperated.
         * 1 1 1 0          If opponent cooperated x2 then defected.
         * 1 1 1 1          If opponent cooperated thrice.
         *
         * Notice, this gives each cell a memory of opponents moves for 3 previous rounds.
         */

        //Copies of the rule number moved over to the right to get rid of the Don't Care.
        int iP1 = i1[0] >> 1;
        int iP2 = i2[0] >> 1;

        //Checking the first bit, or the first move. Saving it to the history.
        int iP1H = iP1 & 1;
        int iP2H = iP2 & 1;

        /*Use the first move to assign points based off of ischeme.
         *
         * For example: iScheme = {{1, 5}, {0, 3}}
         * Player 1 defects(0), player 2 cooperates(1)
         *
         * Player 1 gets iScheme[0][1] or 5 points.
         * Player 2 gets iScheme[1][0] or 0 points.
         */
        i1[1] += iScheme[iP1H][iP2H];
        i2[1] += iScheme[iP2H][iP1H];

        //We don't care about the first move anymore, move to the right.
        iP1 >>= 1;
        iP2 >>= 1;

        //Check to make sure we're playing atleast 2 rounds.
        if (iRounds > 1) {

            //If the history is cooperate, move to the right, else, stay. Get the next bit.
            iP1Hnext = (iP1 >> iP2H) & 1;
            iP2Hnext = (iP2 >> iP1H) & 1;
            iP1H = (iP1H << 1) | iP1Hnext; //Append this bit onto the end of the history.
            iP2H = (iP2H << 1) | iP2Hnext;

            //Add points based on the last move done.
            i1[1] += iScheme[iP1H & 1][iP2H & 1];
            i2[1] += iScheme[iP2H & 1][iP1H & 1];

            //We don't care about the two possible second moves, move to the right x2.
            iP1 >>= 2;
            iP2 >>= 2;

            //Check that we're playing atleast 3 rounds.
            if (iRounds > 2) {
                /*Move based off of the history. Cooperating twice will move the
                 * DNA sequence to the right 11 base 2, or 3 positions. Get the
                 * bit for the first move.
                 */
                iP1Hnext = (iP1 >> iP2H) & 1;
                iP2Hnext = (iP2 >> iP1H) & 1;
                iP1H = (iP1H << 1) | iP1Hnext; //Append the bit onto the history.
                iP2H = (iP2H << 1) | iP2Hnext;
                i1[1] += iScheme[iP1H & 1][iP2H & 1]; //Add points again
                i2[1] += iScheme[iP2H & 1][iP1H & 1];

                //Don't care about 4 possible third moves, move to the right x4.
                iP1 >>= 4;
                iP2 >>= 4;

                /*
                 * As you can see, this follows a pattern, and it all could be
                 * potentially put in a for loop, with a dynamic if statement for
                 * the rounds. This would allow for longer DNA's; however, I can't
                 * represent rules with more than 3 memory as a unique color, so
                 * the code simply stops here. Checking to see that rounds is
                 * atleast 4.
                 */
                for (int r = 3; r < iRounds; r++) {
                    iP1Hnext = (iP1 >> iP2H) & 1; //Get the next move.
                    iP2Hnext = (iP2 >> iP1H) & 1;

                    //Make sure the history only has the opponent's latest 3 moves.
                    iP1H = ((iP1H << 1) | iP1Hnext) & 7;
                    iP2H = ((iP2H << 1) | iP2Hnext) & 7;

                    //Add to the points.
                    i1[1] += iScheme[iP1H & 1][iP2H & 1];
                    i2[1] += iScheme[iP2H & 1][iP1H & 1];
                }
            }
        }

        /*Since this method accepts pointers to array objects, it can update the
         * values without having to return anything
         */

    }


}
