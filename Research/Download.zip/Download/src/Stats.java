/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */


/**
 *
 * @author Brian
 */
public class Stats {
public static void main(String[] args)
    {
    int n = 2;
    double twoFif = 32768.0;
    double twoFifmin = twoFif - 1;
    double odds = 0.0;
    double increment = 1.0/twoFif;
    double multiplier = twoFifmin/twoFif;
        System.out.println("The multiplier is: " + multiplier);

        boolean b = true;

    for (int i = 0; i < n; i++)
        {
            odds += increment;
            if(b && 1.0-odds < 0.01)
            {
                System.out.println(odds);
                System.out.println("Lattice size = " + i);
                b = false;
            }
            increment *=multiplier;
        }

        System.out.println("The odds of having any single rule is: " + odds);

}
}
