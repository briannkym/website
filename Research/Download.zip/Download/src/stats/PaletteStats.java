/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package stats;

import java.util.LinkedList;
import java.util.List;
import pdgame.Lattice;

/**
 * The Palette Stat tallies the number of cells of passed in palette.
 * @author Brian
 */
public class PaletteStats implements Stats
{
    private Lattice l;
    private int[] iPalette;
    private List<int[]> iP = new LinkedList<int[]>();

    public PaletteStats(Lattice l, int[] iPalette)
    {
        this.l = l;
        this.iPalette=iPalette;
    }

    public String toString()
    {
        String s = "Here's a full record of the Hamming Distance:";
        s += "Round";
        for(int j =0; j< iPalette.length; j++)
            {
                s+= "Rule #" + iPalette[j] + ",";
            }

        int iRound=0;
        for(int i[] : iP)
        {
            s+="\n" + iRound + ",";
            iRound ++;
            for(int j =0; j< iPalette.length; j++)
            {
                s+= "," + i[j];
            }
        }

        return s;
    }

    public void updateStats()
    {
        int i[]=new int[iPalette.length];
        for(int[][] x: l.getLattice())
        {
            for(int[] y: x)
            {
                for(int j=0; j<iPalette.length; j++)
                {
                    if(y[0]== iPalette[j])
                    {
                        i[j]++;
                    }
                }
            }
        }
        
        this.iP.add(i);
    }

    public String getSummary()
    {
        String s = "Current Populations:\n";
        int i[]= iP.get(iP.size()-1);
        for(int j =0; j< iPalette.length; j++)
        {
            s+= iPalette[j] + ":  " + i[j] + "\n";
        }

        s += "\n\n Save the Stats for a full print out.";
        return s;
    }
    
}
