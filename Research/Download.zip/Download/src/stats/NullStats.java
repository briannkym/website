
package stats;

/**
 * What a stat does when there is no stat =P.
 * @author Brian
 */
public class NullStats implements Stats
{

    public NullStats(){};

    public String toString()
    {
        return "No Stats selected.";
    }

    public String getSummary()
    {
        return "No Stats selected.";
    }

    public void updateStats()
    {
    }

}
