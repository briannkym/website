
package stats;

import java.util.LinkedList;
import java.util.List;
import pdgame.Lattice;

/**
 * The Point Stats adds all of the points of the individual cells on the lattice
 * for every round.
 * @author Brian
 */
public class PointsStats implements Stats
{

    private Lattice l;
    private List<Integer> iP = new LinkedList<Integer>();

    public PointsStats(Lattice l)
    {
        this.l = l;
    }

    public String toString()
    {
        String s = "Here's a full record of the Lattice Points: \nRounds,Points";
        int iRound = 0;
        for (int i : iP) {
            iRound++;
            s += "\n" + iRound + "," + i;
        }

        return s;
    }

    public String getSummary()
    {
        return "Current Population \nPoints:" + iP.get(iP.size()-1) +
                "\n\n Save the Stats for a full print out.";
    }

    public void updateStats()
    {
        int i = 0;
        for (int[][] x : l.getLattice()) {
            for (int[] y : x) {
                i+= y[1];
            }
        }
        this.iP.add(i);
    }
}
