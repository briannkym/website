package stats;

import java.util.LinkedList;
import java.util.List;
import pdgame.Lattice;

/**
 * This tallies up the current number of cooperations for a given part of a bit
 * DNA. The hope is to find convergence of DNA in some simulations.
 * @author Brian
 */
public class BitStats implements Stats
{

    private Lattice l;
    private List<int[]> sBits = new LinkedList<int[]>();

    public BitStats(Lattice l)
    {
        this.l = l;
    }

    public String toString()
    {
        String s = "Here's a full record of the Bit Stats:"
                + "\nRound,0001,0010,0011,0100,0101,0110,0111,1000"
                + ",1001,1010,1011,1100,1101,1110,1111";
        int iRound = 0;
        for (int[] S : sBits) {
            iRound++;
            s += "\n" + iRound;
            for (int j : S) {
                s += "," + j;
            }
        }

        return s;
    }

    public void updateStats()
    {
        int[] sBits = new int[16];
        for (int[][] x : l.getLattice()) {
            for (int[] y : x) {
                for (int i = 1; i < sBits.length; i++) {
                    sBits[i] += y[0] >> i & 1;
                }
            }
        }
        this.sBits.add(sBits);
    }

    public String getSummary()
    {
        String s = "Current DNA:";
        int i = 1;
        for (int S : sBits.get(sBits.size() - 1)) {
            s += "\n";
            boolean M = false;
            for (int j = 3; j >= 0; j--) {
                if (!M) {
                    if (((i >> j) & 1) == 0) {
                        s += "X";
                    }
                    else {
                        M = true;
                        s += "X";
                    }
                }
                else {
                    if (((i >> j) & 1) == 0) {
                        s += "0";
                    }
                    else {
                        s += "1";
                    }
                }
            }

            s+= "\t" + S;
            i++;
        }
        return s;
    }
}
