
package stats;

/**
 * This is the factory for statistics objects for the Prisoner's Dilemma Game
 * CA
 * @author Brian
 */
public interface Stats
{
    public String toString();
    public String getSummary();
    public void updateStats();
}
