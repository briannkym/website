
package stats;

import java.util.LinkedList;
import java.util.List;
import pdgame.Lattice;

/**
 * This simple statistical method measures the number of initial defectors vs.
 * initial cooperators.
 * @author Brian
 */
public class DvsCStats implements Stats
{

    private Lattice l;
    private List<int[]> iHD = new LinkedList<int[]>();

    public DvsCStats(Lattice l)
    {
        this.l = l;
    }

    public String toString()
    {
        String s = "Here's a full record of the number of cells based off the first move:"
                + "\nRound,Defect,Cooperate";

        int iRound = 0;
        for (int i[] : iHD) {
            iRound ++;
            s += "\n" + iRound + "," + i[0] + "," + i[1];
        }

        return s;
    }

    public String getSummary()
    {
        int[] i = iHD.get(iHD.size() - 1);
        return "Last Round:" + "\nDefect \tCooperate"
                + "\n" + i[0] + "\t" + i[1]
                + "\n Save the Stats for a full print out.";
    }

    public void updateStats()
    {
        int[] iHD = {0, 0};
        for (int[][] x : l.getLattice()) {
            for (int[] y : x) {
                if ((y[0] & 2) == 0) {
                    iHD[0]++;
                }
            }
        }

        iHD[1] = l.getLattice().length * l.getLattice()[0].length - iHD[0];
        this.iHD.add(iHD);
    }
}
