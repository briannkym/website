
package stats;

import java.util.LinkedList;
import java.util.List;
import pdgame.Lattice;

/**
 * The Hamming Distance Stat tallies up how many cells will change state in the
 * next round.
 * @author Brian
 */
public class HammingDistanceStats implements Stats{

    private Lattice l;
    private List<Integer> iHD= new LinkedList<Integer>();

    public HammingDistanceStats(Lattice l)
    {
        this.l=l;
    }

    public String toString()
    {
        String s="Here's a full record of the Hamming Distance:\nRounds,Hamming Distance";
        int iRound=0;
        for(int i : iHD)
        {
            iRound ++;
            s+="\n" + iRound + "," + i;
        }

        return s;
    }

    public void updateStats()
    {
        int iHD=0;
        for(int[][] x: l.getLattice())
        {
            for(int[] y: x)
            {
                if(y[0]!=y[2])
                {
                    iHD++;
                }
            }
        }
        this.iHD.add(iHD);
    }

    public String getSummary()
    {
        return "Current Hamming \nDistance:" + iHD.get(iHD.size()-1) +
                "\n\n Save the Stats for a full print out.";
    }

}
