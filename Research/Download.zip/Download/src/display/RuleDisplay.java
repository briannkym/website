/*
 * The Prisoner's Dilemma CA Simulator.
 * Copyright (C) 2011  Brian Nakayama
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Contact information as of 2013: 
 * briannkym@gmail.com
 * (719)686-4619
 */

package display;

import java.awt.image.BufferedImage;

/**
 * Draw the rules in blue and green, giving initial defectors a red tint.
 * @author Brian
 */
public class RuleDisplay implements Display
{

    /**
     * Based off of the draw rule, which is a bijection from a rule number to a
     * color, it takes in a color and returns the correct rule number.
     * @param iPixel
     * @return The rule number
     */
    public static int ruleFromPixel(int iPixel)
    {
        return (iPixel & 0x0000fffe);
    }

    public void draw(BufferedImage bi, int[][][] iLattice, int iMaxPoints)
    {
        if (iLattice != null && bi != null) {
            for (int x = 0; x < iLattice.length; x++) {
                for (int y = 0; y < iLattice[x].length; y++) {
                    int iColor = 0xff000000 | iLattice[x][y][0];
                    if ((iLattice[x][y][0] & 2) == 0) {
                        iColor |= 0xff0000; //The red tint.
                    }
                    bi.setRGB(x, y, iColor);
                }
            }
        }
    }
}
